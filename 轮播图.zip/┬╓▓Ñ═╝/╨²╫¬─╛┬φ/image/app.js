var oWrap = document.getElementById("wrap");
var aLi = oWrap.getElementsByTagName("li");
var oPre = oWrap.getElementsByClassName("pre")[0];
var oNex= oWrap.getElementsByClassName("nex")[0];
var oSpanDiv = oWrap.getElementsByClassName("span")[0];
var oSpan = oSpanDiv.getElementsByTagName("span");


window.onload = function(){
	var spanIndex = 0;
	var isRight = false;
	var timer = null;
	var styleArr = [];
	for(var i=0;i<aLi.length;i++){
		var oImg = aLi[i].getElementsByTagName("img")[0];

		styleArr.push([getStyle(aLi[i],"left"),getStyle(aLi[i],"top"),getStyle(aLi[i],"zIndex"),getStyle(aLi[i],"opacity"),getStyle(oImg,"width")]);
	}
	timer = setInterval(function(){
		move();
	},2000);


	oPre.addEventListener("mouseover",function(){clearInterval(timer)},false);
	oNex.addEventListener("mouseover",function(){clearInterval(timer)},false);
	oPre.addEventListener("mouseout",function(){timer = setInterval(function(){
		isRight = false;
		move();
	},2000);},false);
	oNex.addEventListener("mouseout",function(){timer = setInterval(function(){
		isRight = false;
		move();
	},2000);},false);
	oPre.addEventListener("click",function(){
		isRight = true;
		move();
	},false);
	oNex.addEventListener("click",function(){
		isRight = false;
		move();
	},false);
	
	function move(){
		if(isRight){
			styleArr.push(styleArr[0]);
			styleArr.shift();
		}else{
			styleArr.unshift(styleArr[styleArr.length-1]);
			styleArr.pop();
		}
		controlSpanIndex();
		for(var i=0;i<aLi.length;i++){
			aLi[i].style.left = styleArr[i][0];
			aLi[i].style.top = styleArr[i][1];
			aLi[i].style.zIndex = styleArr[i][2];
			aLi[i].style.opacity = styleArr[i][3];
			aLi[i].getElementsByTagName("img")[0].style.width = styleArr[i][4];
		}
	}

	function getStyle(obj,name){
		return obj.currentStyle?obj.currentStyle[name]:getComputedStyle(obj,null)[name];
	}

	function controlSpanIndex(){
		if(!isRight){
			if(spanIndex==7){
				spanIndex=0;
			}else{
				spanIndex++;
			}
		}else{
			if(spanIndex==0){
				spanIndex=7;
			}else{
				spanIndex--;
			}
		}
		for(var i=0;i<oSpan.length;i++){
			if(oSpan[i].classList.contains('selected')){
				oSpan[i].classList.remove("selected");
			}
		}
		oSpan[spanIndex].classList.add("selected");
	}
}
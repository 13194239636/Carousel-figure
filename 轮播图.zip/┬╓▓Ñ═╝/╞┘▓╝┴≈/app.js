window.onload = function(){
	/*模拟后台数据*/
	var data = ["25.jpeg","26.jpeg","27.jpeg","28.jpeg","29.jpeg","30.jpeg","31.jpeg","32.jpeg","33.jpeg","34.jpeg"];
	var dir = "../images/1/";

	var oParent = document.getElementById("wrapper");
	var oBox = oParent.getElementsByClassName("box");
	var imgWidth = oBox[0].offsetWidth;
	var imgNum =  Math.floor(document.documentElement.clientWidth/imgWidth);
	oParent.style.cssText = "width:"+imgNum*imgWidth+"px;margin:0 auto;";
	var height = [];
	for(var i=0;i<imgNum;i++){
		height.push(oBox[i].offsetHeight);
	}
	setImgLocation();

	/*根据模拟的后台数据和滚动条高度来动态加载*/
	window.onscroll = function(){
		var scrollDistance = document.documentElement.scrollTop||document.body.scrollTop;
		var lastImgTop = oBox[oParent.getElementsByClassName("box").length-1].offsetTop;
		var pageHeight = document.documentElement.clientHeight||document.body.clientHeight;
		if(scrollDistance+pageHeight>lastImgTop){
			for(var i=0;i<data.length;i++){
				var newBox = document.createElement("div");
				newBox.classList.add("box");
				var newBoxImg = document.createElement("div");
				newBoxImg.classList.add("box_img");
				var newImg = new Image();
				newImg.classList.add("img");
				var newImgIndex = Math.floor(Math.random()*data.length)
				newImg.src = dir+data[newImgIndex];
				//因为图片加载问题，还没加载完成，也就是说box盒子的高度还没有设置好，就已经添加到DOM中了，导致图片出现重叠问题
				//解决办法是，用图片的onload事件，或者服务器端给图片的时候把高度也带过来了。提前设置好盒子高度，不至于重叠。
				newBoxImg.appendChild(newImg);
				newBox.appendChild(newBoxImg);
				oParent.appendChild(newBox);
				setAddImgLocation();
			}
		}
	}


	function getImgLocation(heightArr){
		for(var i=0;i<imgNum;i++){
			if(height[i]==Math.min.apply(null,heightArr)){
				return i;
			}
		}
	}
	function setImgLocation(){
		for(var i=imgNum;i<oBox.length;i++){
			oBox[i].style.position = "absolute";
			oBox[i].style.left = getImgLocation(height)*imgWidth+"px";
			oBox[i].style.top = height[getImgLocation(height)]+"px";
			height[getImgLocation(height)]+=oBox[i].offsetHeight;
		}
	}
	function setAddImgLocation(){
			var last = oParent.getElementsByClassName("box").length-1;
			oBox[last].style.position = "absolute";
			oBox[last].style.left = getImgLocation(height)*imgWidth+"px";
			oBox[last].style.top = height[getImgLocation(height)]+"px";
			height[getImgLocation(height)]+=oBox[last].offsetHeight;
	}
}



var oWrap = document.getElementById("wrap");
var oUl = document.getElementsByTagName("ul")[0];
var oLi = oUl.getElementsByTagName("li");
var oPre = document.getElementById("pre");
var oNex = document.getElementById("nex");
var length = oLi.length;
var Height = oLi[0].clientHeight;
var moveHeight = 0;


window.onload = function(){
	var index = 0;
	var timer = null;
	var isDown = true;

	timer = setInterval(function(){
		move();
	},3000);
	oPre.addEventListener("mouseover",function(){clearInterval(timer)},false);
	oNex.addEventListener("mouseover",function(){clearInterval(timer)},false);
	oPre.addEventListener("mouseout",function(){
		timer = setInterval(function(){
			move();
		},3000);
	},false);
	oNex.addEventListener("mouseout",function(){
		timer = setInterval(function(){
			move();
		},3000);
	},false);
	oPre.addEventListener("click",function(){
		isDown = false;
		move();
	},false);
	oNex.addEventListener("click",function(){
		isDown = true;
		move();
	},false);

	function move(){		
		if(isDown){
			toDown();
		}else{
			toUp();
		}
		oUl.style.transform = "translateY("+-moveHeight+"px)";
		buttonShow();
	}


	function toDown(){
		if(moveHeight/Height==length-1){
			isDown = false;
			toUp();
		}else{
			moveHeight+=Height;
		}
	}

	function toUp(){
		if(moveHeight/Height==0){
			isDown = true;
			toDown();
		}else{
			moveHeight-=Height;
		}
	}
	function buttonShow(){
		if(moveHeight/Height==0){
			oPre.style.display = "none";
		}else{
			oPre.style.display = "block";
		}
		if(moveHeight/Height==length-1){
			oNex.style.display = "none";
		}else{
			oNex.style.display = "block";
		}
	}
}
var oWrap = document.getElementById("wrap");
var oLi = oWrap.getElementsByTagName("li");
var oPre = document.getElementById("pre");
var oNex = document.getElementById("nex");
var length = oLi.length;

window.onload = function(){
	var index = 0;
	var timer = null;
	var speed = 5000;

	timer = setInterval(function(){
		backward();
		show();
	},speed);
	oPre.addEventListener("mouseover",function(){
		clearInterval(timer);
	},false);

	oNex.addEventListener("mouseover",function(){
		clearInterval(timer);
	},false);

	oPre.addEventListener("mouseout",function(){
		timer = setInterval(function(){
			backward();
			show();
		},speed);
	},false);

	oNex.addEventListener("mouseout",function(){
		timer = setInterval(function(){
			backward();
			show();
		},speed);
	},false);

	oPre.addEventListener("click",function(){
		forWard();
		show();
	},false);

	oNex.addEventListener("click",function(){
		backward();
		show();
	},false);

	function forWard(){
		if(index==0){
			index=length-1;
		}else{
			index--;
		}
	}

	function show(){
		for(var i=0;i<oLi.length;i++){
			oLi[i].setAttribute("class"," ");
			oLi[i].style.transitionDelay = "initial";
		}
		oLi[index].setAttribute("class","show");
		oLi[index].style.transitionDelay = 0.8+"s";
	}
	function backward(){
		if(index==length-1){
			index=0;
		}else{
			index++;
		}
	}

}
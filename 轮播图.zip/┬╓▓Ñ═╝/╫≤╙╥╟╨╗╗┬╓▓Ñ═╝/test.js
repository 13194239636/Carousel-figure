//获取相应的元素
var oWrap = document.getElementsByClassName("wrap")[0];
var oUl = oWrap.getElementsByTagName("ul")[0];
var oPre = document.getElementsByClassName("pre")[0];
var oNex = document.getElementsByClassName("nex")[0];
var imgLength = oUl.getElementsByTagName("li").length-1;
var width = oWrap.clientWidth;

window.onload = function(){
	var timer = null;//声明定时器
	var distance = 0;//当前图片的距离，也可以用index来标识
	var isRight = true;//ul是否还应该往右
	var speed = 3000;//移动速度
	timer = setInterval(move,speed);//打开页面自动开启定时器
	oPre.addEventListener("click",function(){movePre(),buttonShow()},false);//给上一个按钮添加点击事件
	oPre.addEventListener("mouseover",function(){//上一个按钮添加鼠标进入事件
		clearInterval(timer);//鼠标移入则清掉定时器，即停止轮播
	},false);
	oPre.addEventListener("mouseout",function(){//上一个按钮添加鼠标移除事件
		timer = setInterval(move,speed);//鼠标移出又再次打开定时器
	},false);
	oNex.addEventListener("click",function(){moveNex(),buttonShow()},false);//同上
	oNex.addEventListener("mouseover",function(){
		clearInterval(timer);
	},false);
	oNex.addEventListener("mouseout",function(){
		timer = setInterval(move,speed);
	},false);

	function movePre(){//往上移动函数
		distance+=width;
		oUl.style.transform = "translate("+distance+"px)";
	}
	function moveNex(){//往下移动函数
		distance-=width;
		oUl.style.transform = "translate("+distance+"px)";
	}

	function move(){//移动函数
		if(isRight){//判断是应该左移动还是右移动
			distance-=width;
			oUl.style.transform = "translate("+distance+"px)";
		}else{
			distance+=width;
			oUl.style.transform = "translate("+distance+"px)";
		}
		buttonShow();
	}
	function buttonShow(){//上一个和下一个按钮的显示与隐藏
		if(distance==-width*imgLength){//如果此时为最右边下一个按钮隐藏
			isRight=false;
			oNex.style.display = "none";
		}
		if(distance!=0){//只要不在最左边，上一个按钮就恢复显示
			oPre.style.display = "block";
		}
		if(distance==0){//如果此时为最左边，上一个按钮隐藏
			isRight=true;
			oPre.style.display = "none";
		}
		if(distance!=-width*imgLength){//只要不在最右边，下一个按钮显示
			oNex.style.display = "block";
		}
	}
}
